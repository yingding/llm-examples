def hello():
    print("Hello from ApplyLlm")
    return